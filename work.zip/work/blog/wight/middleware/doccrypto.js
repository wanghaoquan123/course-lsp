class dc {

  constructor (options) {
    this.config = options.config;
    this.pass = options.pass;
  }

  async middleware (c, next) {
    
  }

}

module.exports = dc;
