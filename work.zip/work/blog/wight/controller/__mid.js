module.exports = [
    /* {
        name : 'cors',
    }*/
];
