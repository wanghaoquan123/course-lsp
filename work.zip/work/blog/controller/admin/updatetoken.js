class updatetoken {
  constructor ()
  {

  }

  /**
   * 
   * @param {*} c 
   * token交换属于登录过程
   */
  async create (c) {

  }


}

module.exports = updatetoken;
