module.exports = [
  {
    name : 'adminpass'
  }
];