module.exports = [
  {
    name : 'cors'
  },
  {
    name : 'apicache'
  }
];